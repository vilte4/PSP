create unique index PRIMARY_KEY_2
    on USER (ID);

